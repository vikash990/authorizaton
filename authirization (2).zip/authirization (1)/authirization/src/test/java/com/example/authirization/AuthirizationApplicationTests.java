package com.example.authirization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthirizationApplicationTests {

	@Test
	void contextLoads() {
	}

}
