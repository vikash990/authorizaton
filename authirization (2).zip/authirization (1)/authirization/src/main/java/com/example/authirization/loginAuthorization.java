package es.softtek.jwtDemo.controller;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.web.bind.annotation.PostMpping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestController;

import es.softtek.jwtDemo.dto.User;
import io.jsonwebtoken.jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController

public class UserController{

    @PostMpping("user")
    public user login(@RequestParam("user") String username,@RequestParam("password") String pwd){

     // you can authorize user and then set token

     // 1 queer to check the username that you receice from client is present or not
     // 2 if prsent you will check the password is matching or not
     // 3 if username is not present then you make and account
     // 4 deprecet the password from the database and match with the password received from the client
    
        String token=getJWTToken(username);
        User user=new User();
        user.setUser(username);
        user.setToken(token);
        return user;
    }

    private String getJWTToken(String username){
        String secretKey="mySecretKey";
        List<GrantedAuthority> grantedAuthorities=AuthorityUtils.commSeperatedStringToAuthoriyList("ROLE_USER");

        String token=jwts.builder().setId("softtekJWT").setSubject(username).claim("authorities",grantedAuthorities.stream().map(GrantedAuthority::getAuthority).collect(Collectors.toList()))
        .setIssueAt(new Date(System.currentTimeMillis)).setExpiration(new Date(System.currentTimeMillis()+ 600000))
        .signWith(SignatureAlgorithm.HS512,secretKey.getBytes()).compact();

        return "Bearer" + token;
    }
}
