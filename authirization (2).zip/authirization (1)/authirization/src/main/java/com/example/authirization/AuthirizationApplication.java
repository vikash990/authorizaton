package com.example.authirization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthirizationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthirizationApplication.class, args);
	}

}
